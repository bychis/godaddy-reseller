# Godaddy reseller API client implementation
## Steps to launch code
- creating virtual env: ```python3 -m venv venv```
- install the requirements ```pip3 install -r requirements.txt```
- start the main code: ```python3 main.py```